import random


RANDOM_INT = random.randint(1, 100)
