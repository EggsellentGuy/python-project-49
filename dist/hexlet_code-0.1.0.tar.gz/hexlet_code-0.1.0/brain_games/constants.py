COLCULATE_SIMWOLS = ['+', '-', '*']

MAX_RAUNDS = 3
