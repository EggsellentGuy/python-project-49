COLCULATE_SIMWOLS = ['+', '-', '*']

MAX_RAUNDS = 3

WELCOME_PHRASE = 'Welcome to the Brain Games!'
